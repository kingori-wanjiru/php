<!DOCTYPE html>
<html>
<head>
  <title> Students</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <h1>Student</h1>
    <nav>
      <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="students.php">Students</a></li>
        <li><a href="sports.php">Sports</a></li>
        <li><a href="courses.php">Courses</a></li>
      </ul>
    </nav>
  </header>
  <aside>
    <ul>
      <li><a href="#">Add Record</a></li>
      <li><a href="#">Edit Record</a></li>
      <li><a href="#">Display Records</a></li>
      <li><a href="#">Delete Record</a></li>
    </ul>
  </aside>
  <main>
    <h2>Students</h2>
    <p>we have well performing students and past alumni working greatly in the fields they specialized in</p>
    <!-- Form to add a new course record -->
    <form action="conn.php" method="POST">
      <label for="NAME">Course Name:</label>
      <input type="text" id="NAME" name="Name" required>
      <label for="administrator">administrator:</label>
      <input type="text" id="admission" name="admission" required>
      <button type="submit">Add Course</button>
    </form>
  </main>
</body>
</html>
