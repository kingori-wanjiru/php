 <!DOCTYPE html>
<html>
<head>
  <title>Courses</title>
  <link rel="stylesheet" type="text/css" href="styles.css">
</head>
<body>
  <header>
    <h1>Courses</h1>
    <nav>
      <ul>
        <li><a href="school managemnt.html">Home</a></li>
        <li><a href="students.php">Students</a></li>
        <li><a href="sports.php">Sports</a></li>
        <li><a href="courses.php">Courses</a></li>
      </ul>
    </nav>
  </header>
  <aside>
    <ul>
      <li><a href="#">Add Record</a></li>
      <li><a href="#">Edit Record</a></li>
      <li><a href="#">Display Records</a></li>
      <li><a href="#">Delete Record</a></li>
    </ul>
  </aside>
  <main>
    <h2><b>COURSES</b></h2>
    <p>WE OFFER THE FOLLOWING COURSES AT SINAI:</p>
    <ol>
      <li>ENGINEERING COURSES
        <ul>
          <li>MECHANICAL ENGINEERING</li>
          <li>ELECTRICAL ENGINEERING</li>
          <li>COMPUTER ENGINEERING</li>
          <li>ENVIRONMENTAL ENGINEERING</li>
        </ul>
      </li>
      <li>IT
        <ul>
          <li>MEDIA</li>
          <li>HOSPITALITY</li>
          <li>BUSINESS COURSES</li>
        </ul>
      </li>
      <li>ENGINEERING
        <ul>
          <li>MECHANICAL ENGINEERING</li>
          <li>ELECTRICAL ENGINEERING</li>
          <li>COMPUTER ENGINEERING</li>
          <li>ENVIRONMENTAL ENGINEERING</li>
        </ul>
      </li>
      <li>IT
        <ul>
          <li>SCIENCE IN IT</li>
          <li>BUSINESS IN IT</li>
          <li>COMPUTER SCIENCE</li>
        </ul>
      </li>
      <li>BUSINESS COURSES
        <ul>
          <li>ECONOMICS</li>
          <li>STATISTICS</li>
          <li>ACCOUNTING AND FINANCE</li>
        </ul>
      </li>
    </ol>

    <!-- Form to add a new course record -->
    <form action="conn.php" method="POST">
      <label for="NAMEOFCOURSE">Course Name:</label>
      <input type="text" id="NAMEOFCOURSE" name="courseName" required>

      <label for="COURSENO">Course Code:</label>
      <input type="text" id="COURSENO" name="courseCode" required>

      <label for="lecturer">Lecturer:</label>
      <input type="text" id="lecturer" name="lecturer" required>

      <button type="submit">Add Course</button>
    </form>
  </main>
</body>
</html>

  </main>
</body>
</html>
