<?php
    // Database connection
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "school management system";

    $conn = mysqli_connect($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection error: " . $conn->connect_error);
    }

// Check if form is submitted
if (isset($_POST['NAME']) && isset($_POST['ADMISSION'])) {
  // Retrieve data from the form
  $NAME = $_POST["NAME"];
  $ADMISSION = $_POST["ADMISSION"];
  

  // Insert into table
  $tablename = 'details';
  $insert_sql = "INSERT INTO details (NAME, ADMISSION) VALUES ( '$NAME', '$ADMISSION')";

  if (mysqli_query($conn, $insert_sql)) {
      echo "SUCCESS";
  } else {
      echo "FAILED: " . $insert_sql . "<br>" . mysqli_error($conn);
  }
}

    
$conn->close();
    ?>