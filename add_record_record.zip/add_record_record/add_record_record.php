<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<form action="add_record_record.php" method="post">
    custom id <input type="text" name="CUSTOM_ID"> <br><br>
    contractname <input type="text" name="CONTRACTNAME"><br><br>
    address <input type="text" name="ADDRESS" id="ADDRESS"><br>
    city <input type="text" name="CITY"> <br><br>
    postcode <input type="text" name="POSTCODE" ><br><br>
    country <input type="text" name="COUNTRY" ><br><br>
    <input type="submit" value="Submit">
</form>

<?php
// Database connection
$host = 'localhost';
$username = 'root';
$password = '';
$database = 'business';

// Connect to database using mysqli
$conn = mysqli_connect($host, $username, $password, $database);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if form is submitted
if (isset($_POST['CUSTOM_ID']) && isset($_POST['CONTRACTNAME']) && isset($_POST['ADDRESS']) && isset($_POST['CITY']) && isset($_POST['POSTCODE']) && isset($_POST['COUNTRY'])) {
    // Retrieve data from the form and sanitize input
    $CUSTOM_ID = mysqli_real_escape_string($conn, $_POST["CUSTOM_ID"]);
    $CONTRACTNAME = mysqli_real_escape_string($conn, $_POST["CONTRACTNAME"]);
    $ADDRESS = mysqli_real_escape_string($conn, $_POST["ADDRESS"]);
    $CITY = mysqli_real_escape_string($conn, $_POST["CITY"]);
    $POSTCODE = mysqli_real_escape_string($conn, $_POST["POSTCODE"]);
    $COUNTRY = mysqli_real_escape_string($conn, $_POST["COUNTRY"]);

    // Insert into table
    $tablename = 'tablename'; // Change 'tablename' to your actual table name
    $insert_sql = "INSERT INTO $tablename (CUSTOM_ID, CONTRACTNAME, ADDRESS, CITY, POSTCODE, COUNTRY) VALUES ('$CUSTOM_ID', '$CONTRACTNAME', '$ADDRESS', '$CITY', '$POSTCODE', '$COUNTRY')";

    if (mysqli_query($conn, $insert_sql)) {
        echo "SUCCESS";
    } else {
        echo "FAILED: " . $insert_sql . "<br>" . mysqli_error($conn);
    }
}

// Display records from the table
$select_sql = "SELECT * FROM $tablename"; // Change 'tablename' to your actual table name
$result = mysqli_query($conn, $select_sql);

while ($arrRecords = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
    echo "<p>" . $arrRecords["CUSTOM_ID"] . " ";
    echo $arrRecords["CONTRACTNAME"] . " ";
    echo $arrRecords["ADDRESS"] . " ";
    echo $arrRecords["CITY"] . " ";
    echo $arrRecords["POSTCODE"] . " ";
    echo $arrRecords["COUNTRY"] . " ";
    echo "</p>";
}
?>

</body>
</html>
